Name: James Lee
Email: leej37@rpi.edu
github account: jemzlee4
slack handle: jemzlee
